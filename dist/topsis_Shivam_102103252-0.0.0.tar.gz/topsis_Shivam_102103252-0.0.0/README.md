Topsis technique has been commonly used to solve decision-making problems. This technique is based on the comparison between all the alternatives included in the problem.

